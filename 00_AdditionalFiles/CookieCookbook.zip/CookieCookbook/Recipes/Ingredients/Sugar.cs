﻿namespace CookieCookbook.Recipes.Ingredients;

public class Sugar : Ingredient
{
    public override int Id => 5;
    public override string Name => "Sugar";
}

